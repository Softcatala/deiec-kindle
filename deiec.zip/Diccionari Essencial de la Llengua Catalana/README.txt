Diccionari essencial de la llengua catalana (DEIEC) en format MOBI

© Institut d’Estudis Catalans
Carrer del Carme, 47. 08001 Barcelona
URL: https://deiec.iec.cat/

ISBN: 978-84-9965-713-4
DOI: 10.2436/10.2500.16.1

Aquesta obra és d’ús lliure, però està sotmesa a les condicions de la llicència pública de Creative Commons. Es pot reproduir, distribuir i comunicar l’obra sempre que se’n reconegui l’autoria i l’entitat que la publica i no se’n faci un ús comercial ni cap obra derivada. Es pot trobar una còpia completa dels termes d’aquesta llicència a l’adreça: http://creativecommons.org/licenses/by-nc-nd/3.0/es/deed.ca.

Data de compilació: 3 de gener de 2025

Compilat per Pere Orga (https://orga.cat).
